﻿using UnityEngine;

namespace Dest
{
	namespace Math
	{
		/// <summary>
		/// Contains information about intersection of Segment3 and Sphere3
		/// </summary>
		public struct Segment3Sphere3Intr
		{
			/// <summary>
			/// Equals to IntersectionTypes.Point or IntersectionTypes.Segment if intersection occured otherwise IntersectionTypes.Empty
			/// </summary>
			public IntersectionTypes IntersectionType;

			/// <summary>
			/// Number of intersection points.
			/// IntersectionTypes.Empty: 0;
			/// IntersectionTypes.Point: 1;
			/// IntersectionTypes.Segment: 2.
			/// </summary>
			public int Quantity;

			/// <summary>
			/// First intersection point
			/// </summary>
			public Vector3 Point0;

			/// <summary>
			/// Second intersection point
			/// </summary>
			public Vector3 Point1;

			/// <summary>
			/// Segment evaluation parameter of the first intersection point
			/// </summary>
			public float SegmentParameter0;

			/// <summary>
			/// Segment evaluation parameter of the second intersection point
			/// </summary>
			public float SegmentParameter1;
		}

		public static partial class Intersection
		{
			/// <summary>
			/// Tests if a segment intersects a sphere. Returns true if intersection occurs false otherwise.
			/// </summary>
			public static bool TestSegment3Sphere3(ref Segment3 segment, ref Sphere3 sphere)
			{
				Vector3 diff = segment.Center - sphere.Center;
				float a0 = diff.Dot(diff) - sphere.Radius * sphere.Radius;
				float a1 = segment.Direction.Dot(diff);
				float discr = a1 * a1 - a0;
				if (discr < 0f)
				{
					return false;
				}

				float tmp0 = segment.Extent * segment.Extent + a0;
				float tmp1 = 2f * a1 * segment.Extent;
				float qm = tmp0 - tmp1;
				float qp = tmp0 + tmp1;
				if (qm * qp <= 0f)
				{
					return true;
				}

				return qm > 0f && Mathf.Abs(a1) < segment.Extent;
			}

			/// <summary>
			/// Tests if a segment intersects a sphere and finds intersection parameters. Returns true if intersection occurs false otherwise.
			/// </summary>
			public static bool FindSegment3Sphere3(ref Segment3 segment, ref Sphere3 sphere, out Segment3Sphere3Intr info)
			{
				Vector3 diff = segment.Center - sphere.Center;
				float a0 = diff.Dot(diff) - sphere.Radius * sphere.Radius;
				float a1 = segment.Direction.Dot(diff);
				float discr = a1 * a1 - a0;
				if (discr < 0f)
				{
					info = new Segment3Sphere3Intr();
					return false;
				}

				float tmp0 = segment.Extent * segment.Extent + a0;
				float tmp1 = 2f * a1 * segment.Extent;
				float qm = tmp0 - tmp1;
				float qp = tmp0 + tmp1;
				float root;
				if (qm * qp <= 0f)
				{
					root = Mathf.Sqrt(discr);

					info.SegmentParameter0 = (qm > 0f ? -a1 - root : -a1 + root);
					info.SegmentParameter1 = 0f;
					info.Point0            = segment.Center + info.SegmentParameter0 * segment.Direction;
					info.Point1            = Vector3.zero;
					info.SegmentParameter0 = (info.SegmentParameter0 + segment.Extent) / (2f * segment.Extent);
					info.Quantity          = 1;
					info.IntersectionType  = IntersectionTypes.Point;
					return true;
				}

				if (qm > 0f && Mathf.Abs(a1) < segment.Extent)
				{
					if (discr >= Mathfex.ZeroTolerance)
					{
						root = Mathf.Sqrt(discr);
						
						info.SegmentParameter0 = -a1 - root;
						info.SegmentParameter1 = -a1 + root;
						info.Point0            = segment.Center + info.SegmentParameter0  * segment.Direction;
						info.Point1            = segment.Center + info.SegmentParameter1 * segment.Direction;
						info.SegmentParameter0 = (info.SegmentParameter0  + segment.Extent) / (2f * segment.Extent);
						info.SegmentParameter1 = (info.SegmentParameter1 + segment.Extent) / (2f * segment.Extent);
						info.Quantity          = 2;
						info.IntersectionType  = IntersectionTypes.Segment;
					}
					else
					{
						info.SegmentParameter0 = -a1;
						info.SegmentParameter1 = 0f;
						info.Point0            = segment.Center + info.SegmentParameter0 * segment.Direction;
						info.Point1            = Vector3.zero;
						info.SegmentParameter0 = (info.SegmentParameter0 + segment.Extent) / (2f * segment.Extent);
						info.Quantity          = 1;
						info.IntersectionType  = IntersectionTypes.Point;
					}
				}
				else
				{
					info = new Segment3Sphere3Intr();
				}

				return info.Quantity > 0;
			}
		}
	}
}
