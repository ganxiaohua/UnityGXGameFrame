﻿using UnityEngine;

namespace Dest
{
	namespace Math
	{
		public static partial class Distance
		{
			//TODO
		}
	}
}
